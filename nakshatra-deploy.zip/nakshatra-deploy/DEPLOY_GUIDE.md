# 🚀 NakshAtra — Deploy Guide
## Live in 10 minutes, completely free

---

## WHAT YOU GET
- ✅ Your website live at a real URL (e.g. nakshatra.vercel.app)
- ✅ AI chat powered by Google Gemini (1,500 free requests/day)
- ✅ API key hidden on server — users can never steal it
- ✅ Free SSL certificate (https://)
- ✅ Custom domain support (optional, also free)

---

## STEP 1 — Get Your Free Gemini API Key (2 min)

1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key — it looks like: `AIzaSyXXXXXXXXXXXXXXXXXXXXXX`
5. Save it somewhere safe (notepad, etc.)

> Free tier = 1,500 requests/day = ~1,500 AI chats per day. More than enough to start.

---

## STEP 2 — Create a GitHub Account (1 min)

If you already have GitHub, skip this.

1. Go to: https://github.com
2. Click **"Sign up"**
3. Enter email, password, username
4. Verify your email

---

## STEP 3 — Upload Your Project to GitHub (3 min)

1. Go to: https://github.com/new
2. Repository name: `nakshatra` (or any name you like)
3. Select **"Public"**
4. Click **"Create repository"**
5. On the next page, click **"uploading an existing file"**
6. Drag and drop the entire **`nakshatra-deploy`** folder contents:
   - `vercel.json`
   - `api/` folder (contains `chat.js`)
   - `public/` folder (contains `index.html`)
7. Click **"Commit changes"**

> Make sure to upload the FOLDER CONTENTS, not the folder itself.
> Your GitHub should show: vercel.json, api/chat.js, public/index.html

---

## STEP 4 — Deploy on Vercel (3 min)

1. Go to: https://vercel.com
2. Click **"Sign Up"** → choose **"Continue with GitHub"**
3. Authorize Vercel to access your GitHub
4. Click **"Add New Project"**
5. Find your `nakshatra` repository → click **"Import"**
6. Leave all settings as default
7. Click **"Deploy"**

Wait ~30 seconds. You'll see a success screen. 🎉

---

## STEP 5 — Add Your API Key (2 min) ⚠️ CRITICAL

Your site is live but the AI chat won't work yet — you need to add your Gemini key as a secret environment variable.

1. On your Vercel dashboard, click your project
2. Go to **Settings** → **Environment Variables**
3. Click **"Add New"**
4. Name: `GEMINI_API_KEY`
5. Value: paste your Gemini key (`AIzaSy...`)
6. Click **"Save"**
7. Go to **Deployments** → click the three dots on your latest deployment → **"Redeploy"**

Done! Your AI chat is now live and secure. ✅

---

## STEP 6 — Get Your Live URL

1. Go to your Vercel project dashboard
2. You'll see your URL: `https://nakshatra-xxxx.vercel.app`
3. Share this with anyone!

---

## OPTIONAL — Custom Domain (Free)

Want `www.nakshatra.in` instead of `nakshatra.vercel.app`?

1. Buy a domain from GoDaddy, Namecheap, or Hostinger (~₹500–800/year for .in)
2. In Vercel: Settings → Domains → Add your domain
3. Vercel shows you DNS settings — copy them to your domain provider
4. Done in ~5 minutes

---

## TROUBLESHOOTING

**AI chat not working?**
→ Check that GEMINI_API_KEY is set correctly in Vercel Environment Variables
→ Redeploy after adding the key

**Page not loading?**
→ Make sure `public/index.html` exists in your GitHub repo
→ Check `vercel.json` is in the root (not inside a folder)

**"Method not allowed" error?**
→ The API function is working correctly — this just means someone tried a GET request

**Want to update the website?**
→ Edit `public/index.html` on GitHub → Vercel auto-redeploys in 30 seconds

---

## YOUR FILE STRUCTURE (must look exactly like this on GitHub)

```
nakshatra/                  ← your GitHub repo root
├── vercel.json             ← Vercel config
├── api/
│   └── chat.js             ← serverless function (API key lives here)
└── public/
    └── index.html          ← your website
```

---

## COSTS SUMMARY

| Service         | Cost         |
|----------------|--------------|
| Vercel hosting  | FREE forever |
| Gemini API      | FREE (1500/day) |
| SSL certificate | FREE (auto)  |
| Custom domain   | ₹500–800/year (optional) |

**Total to launch: ₹0** ✨

---

## SCALING UP (when you get traffic)

When you outgrow 1,500 AI chats/day:
- Gemini paid tier: ~₹0.0007 per message (very cheap)
- OR switch to Groq (free, faster): get key at console.groq.com

To switch to Groq, just ask me and I'll update the `api/chat.js` file.

---

Made with ✦ — NakshAtra
